import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { updateTestScore, updateCurrentQuestionValues } from "./redux/actions";

// eslint-disable-next-line
function prompt() {
  let student = prompt("Please Enter Your Name");
  if (student != null) {
    document.getElementsByClassName("student-name").innerHTML =
      "Hello" + student;
  }
}
export default function App() {
  const questions = [
    {
      questionText: "What is the capital of France?",
      answerOptions: [
        { answerText: "New York", isCorrect: false },
        { answerText: "London", isCorrect: false },
        { answerText: "Paris", isCorrect: true },
        { answerText: "Dublin", isCorrect: false },
      ],
    },
    {
      questionText: "Who is CEO of Tesla?",
      answerOptions: [
        { answerText: "Jeff Bezos", isCorrect: false },
        { answerText: "Elon Musk", isCorrect: true },
        { answerText: "Bill Gates", isCorrect: false },
        { answerText: "Tony Stark", isCorrect: false },
      ],
    },
    {
      questionText: "The iPhone was created by which company?",
      answerOptions: [
        { answerText: "Apple", isCorrect: true },
        { answerText: "Intel", isCorrect: false },
        { answerText: "Amazon", isCorrect: false },
        { answerText: "Microsoft", isCorrect: false },
      ],
    },
    {
      questionText: "The iPhone was iiii by which company?",
      answerOptions: [
        { answerText: "Apple", isCorrect: true },
        { answerText: "Intel", isCorrect: false },
        { answerText: "Amazon", isCorrect: false },
        { answerText: "Microsoft", isCorrect: false },
      ],
    },
    {
      questionText: "How many Harry Potter books are there?",
      answerOptions: [
        { answerText: "1", isCorrect: false },
        { answerText: "4", isCorrect: false },
        { answerText: "6", isCorrect: false },
        { answerText: "7", isCorrect: true },
      ],
    },
  ];

  const [nextQuestion, setNextQuestion] = useState(0);
  const [generatedNumbers, setGeneratedNumbers] = useState([]);
  const score = useSelector((state) => state.score);
  const [showScore, setShowScore] = useState(false);
  const currentQuestion = useSelector((state) => state.currentQuestion);
  const dispatch = useDispatch();

  function generateUniqueNumber(maxNumber = 5) {
    let number = Math.random() * maxNumber;
    const checkNumber = validateNumberExistance(number);
    if (checkNumber) {
      generateUniqueNumber();
    } else {
      setGeneratedNumbers([...generatedNumbers, parseInt(number.toFixed(0))]);
    }
  }

  // in order to validate that there is no exisiting number equals to generated one.
  function validateNumberExistance(generatedNumb) {
    let exists = false;
    generatedNumbers.map((num) => {
      if (num === parseInt(generatedNumb.toFixed(0))) {
        return (exists = true);
      }
    });
    return exists ? true : false;
  }

  useEffect(() => {
    if (generatedNumbers.length < 5) generateUniqueNumber(5);
  }, [generatedNumbers]);

  console.log(questions[currentQuestion]);

  const handleAnswerOptionClick = (isCorrect) => {
    if (isCorrect) dispatch(updateTestScore());

    const nextQuet = generatedNumbers[nextQuestion];
    console.log(nextQuet);
    if (nextQuestion < questions.length) {
      dispatch(updateCurrentQuestionValues(nextQuet));
      setNextQuestion(nextQuestion + 1);
    } else setShowScore(true);
  };

  return (
    <div className="app">
      <div>
        {/* eslint-disable-next-line */}
        <h2 className="student-name" />
      </div>

      {showScore ? (
        <div className="score-section">
          You scored {score} out of {questions.length}
        </div>
      ) : (
        <>
          <div className="question-section">
            <div className="question-count">
              <span>Question {currentQuestion + 1}</span>/{questions.length}
            </div>
            <div className="question-text">
              {questions[currentQuestion]?.questionText}
            </div>
          </div>
          <div className="answer-section">
            {questions[currentQuestion]?.answerOptions?.map(
              (answerOption, i) => (
                <button
                  key={i}
                  onClick={() =>
                    handleAnswerOptionClick(answerOption.isCorrect)
                  }
                >
                  {answerOption.answerText}
                </button>
              )
            )}
          </div>
        </>
      )}
    </div>
  );
}
